/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Globe, Map, UserCircle, MessageSquare, 
  Plus, Edit2, Trash2, Sparkles, 
  Settings, X, Maximize2, Activity, Brain, Heart, ShieldAlert, ArrowLeft, Moon, Sun
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState('');

  const openModal = (type: string) => {
    setModalType(type);
    setIsModalOpen(true);
  };

  const [isDarkMode, setIsDarkMode] = useState(true);

  return (
    <div id="app-root" className={`flex h-screen w-full overflow-hidden selection:bg-zinc-800 transition-colors duration-500 ${isDarkMode ? 'bg-[#030303] text-zinc-100' : 'bg-zinc-100 text-zinc-900'}`}>
      {/* Sidebar */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} />

      {/* Middle Content (Collapsible) */}
      <AnimatePresence initial={false}>
        {activeTab && (
          <motion.aside 
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: '700px', opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className={`h-full border-r flex-shrink-0 overflow-hidden z-20 shadow-2xl ${isDarkMode ? 'border-white/5 bg-[#080808]' : 'border-black/5 bg-white'}`}
          >
            <div className="w-[700px] h-full flex flex-col">
              <Header activeTab={activeTab} onClose={() => setActiveTab(null)} />
              <div className="flex-1 overflow-y-auto p-6 lg:p-10 scroll-smooth">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.3 }}
                  >
                    {activeTab === 'character' && <CharacterPanel openModal={openModal} />}
                    {activeTab === 'world_rules' && <WorldRulesPanel openModal={openModal} />}
                    {activeTab === 'regional_rules' && <RegionalRulesPanel openModal={openModal} />}
                    {activeTab === 'personal_rules' && <PersonalRulesPanel openModal={openModal} />}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Right Panel: LLM Interaction (Main Area) */}
      <LLMInteractionPanel isDarkMode={isDarkMode} />

      {/* Modals */}
      <AnimatePresence>
        {isModalOpen && (
          <Modal closeModal={() => setIsModalOpen(false)} type={modalType} />
        )}
      </AnimatePresence>
    </div>
  );
}

function Sidebar({ activeTab, setActiveTab, isDarkMode, setIsDarkMode }: { activeTab: string | null, setActiveTab: (tab: string | null) => void, isDarkMode: boolean, setIsDarkMode: (dark: boolean) => void }) {
  const navItems = [
    { id: 'character', icon: User, label: '人物属性' },
    { id: 'world_rules', icon: Globe, label: '世界规则' },
    { id: 'regional_rules', icon: Map, label: '区域规则' },
    { id: 'personal_rules', icon: UserCircle, label: '个人规则' },
  ];

  return (
    <nav id="sidebar-nav" className={`w-20 lg:w-64 flex-shrink-0 glass-panel border-r flex flex-col justify-between z-20 ${isDarkMode ? 'border-white/5' : 'border-black/5 bg-white/60'}`}>
      <div>
        <div className={`h-20 flex items-center justify-center lg:justify-start lg:px-6 border-b ${isDarkMode ? 'border-white/5' : 'border-black/5'}`}>
          <Sparkles className={`w-6 h-6 ${isDarkMode ? 'text-zinc-100' : 'text-zinc-900'}`} />
          <span className={`hidden lg:block ml-3 font-semibold tracking-widest text-lg ${isDarkMode ? 'text-gradient' : 'text-zinc-900'}`}>
            RULE.MODIFIER
          </span>
        </div>
        <div className="p-4 space-y-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => setActiveTab(activeTab === item.id ? null : item.id)}
                className={`w-full flex items-center p-3 rounded-xl transition-all duration-300 group relative ${
                  isActive 
                    ? (isDarkMode ? 'bg-white/10 text-white shadow-[0_0_15px_rgba(255,255,255,0.05)]' : 'bg-black/5 text-black shadow-[0_0_15px_rgba(0,0,0,0.05)]') 
                    : (isDarkMode ? 'text-zinc-500 hover:text-zinc-200 hover:bg-white/5' : 'text-zinc-500 hover:text-zinc-900 hover:bg-black/5')
                }`}
              >
                {isActive && (
                  <motion.div 
                    layoutId="activeTab" 
                    className={`absolute left-0 w-1 h-8 rounded-r-full ${isDarkMode ? 'bg-white' : 'bg-black'}`}
                  />
                )}
                <item.icon className={`w-5 h-5 ${isActive ? (isDarkMode ? 'text-white' : 'text-black') : (isDarkMode ? 'text-zinc-500 group-hover:text-zinc-300' : 'text-zinc-500 group-hover:text-zinc-900')}`} />
                <span className="hidden lg:block ml-3 text-sm font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      <div className={`p-4 border-t ${isDarkMode ? 'border-white/5' : 'border-black/5'} space-y-2`}>
        <button 
          onClick={() => setIsDarkMode(!isDarkMode)}
          className={`w-full flex items-center p-3 rounded-xl transition-all ${isDarkMode ? 'text-zinc-500 hover:text-zinc-200 hover:bg-white/5' : 'text-zinc-500 hover:text-zinc-900 hover:bg-black/5'}`}
        >
          {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          <span className="hidden lg:block ml-3 text-sm font-medium">{isDarkMode ? '浅色模式' : '深色模式'}</span>
        </button>
        <button id="nav-settings" className={`w-full flex items-center p-3 rounded-xl transition-all ${isDarkMode ? 'text-zinc-500 hover:text-zinc-200 hover:bg-white/5' : 'text-zinc-500 hover:text-zinc-900 hover:bg-black/5'}`}>
          <Settings className="w-5 h-5" />
          <span className="hidden lg:block ml-3 text-sm font-medium">系统设置</span>
        </button>
      </div>
    </nav>
  );
}

function Header({ activeTab, onClose }: { activeTab: string, onClose: () => void }) {
  const titles: Record<string, string> = {
    character: '人物属性编辑',
    world_rules: '世界规则管理',
    regional_rules: '区域规则管理',
    personal_rules: '个人规则管理'
  };

  return (
    <header id="main-header" className="h-20 glass-panel border-b border-white/5 flex items-center justify-between px-6 lg:px-10 z-10 sticky top-0">
      <h1 className="text-2xl font-light tracking-wide text-white">
        {titles[activeTab]}
      </h1>
      <button onClick={onClose} className="p-2 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white transition-colors">
        <X className="w-5 h-5" />
      </button>
    </header>
  );
}

function CharacterPanel({ openModal }: { openModal: (type: string) => void }) {
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);

  return (
    <div className="relative h-full">
      <AnimatePresence mode="wait">
        {selectedCharacter ? (
          <motion.div
            key="detail"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <CharacterDetail characterId={selectedCharacter} onBack={() => setSelectedCharacter(null)} openModal={openModal} />
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.3 }}
          >
            <CharacterList onSelect={setSelectedCharacter} openModal={openModal} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function CharacterList({ onSelect, openModal }: { onSelect: (id: string) => void, openModal: (type: string) => void }) {
  const characters = [
    { id: 'CHR-000', name: '玩家 (你)', role: '主角 / 规则掌控者', status: '活跃', lust: 0, affection: 100, fetish: 0, isProtagonist: true },
    { id: 'CHR-001', name: '神宫寺 琉璃', role: '学生会书记', status: '活跃', lust: 75, affection: 42, fetish: 15, isProtagonist: false },
    { id: 'CHR-002', name: '白银 辉夜', role: '学生会会长', status: '活跃', lust: 10, affection: 10, fetish: 5, isProtagonist: false },
    { id: 'CHR-003', name: '早坂 爱', role: '专属女仆', status: '活跃', lust: 30, affection: 60, fetish: 30, isProtagonist: false },
  ];

  return (
    <section id="panel-character-list" className="space-y-6 pb-20">
      <div className="flex justify-between items-center">
        <p className="text-zinc-400 text-sm">管理当前世界中的所有角色实体。</p>
        <button onClick={() => openModal('add_character')} className="glass-button px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 text-zinc-200">
          <Plus className="w-4 h-4" /> 新增角色
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {characters.map((char) => (
          <article 
            key={char.id}
            onClick={() => onSelect(char.id)}
            className={`glass-panel p-5 rounded-2xl cursor-pointer group hover:border-white/20 transition-all relative overflow-hidden ${char.isProtagonist ? 'border-white/20 bg-white/[0.03]' : ''}`}
          >
            {char.isProtagonist && (
              <div className="absolute top-0 right-0 bg-white/10 text-white text-[10px] px-3 py-1 rounded-bl-lg font-medium tracking-wider">
                PROTAGONIST
              </div>
            )}
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${char.isProtagonist ? 'bg-white/10 text-white' : 'bg-white/5 text-zinc-400 group-hover:text-zinc-200'}`}>
                <User className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-medium text-zinc-100">{char.name}</h4>
                <p className="text-xs text-zinc-500">{char.role} | {char.id}</p>
              </div>
            </div>
            <div className="space-y-2">
              {!char.isProtagonist && (
                <>
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500">好感度 AFFECTION</span>
                    <span className="text-zinc-300 font-mono">{char.affection}%</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500">发情值 LUST</span>
                    <span className="text-zinc-300 font-mono">{char.lust}%</span>
                  </div>
                </>
              )}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function CharacterDetail({ characterId, onBack, openModal }: { characterId: string, onBack: () => void, openModal: (type: string) => void }) {
  const isProtagonist = characterId === 'CHR-000';
  const name = isProtagonist ? '玩家 (你)' : '神宫寺 琉璃';

  return (
    <section id="panel-character-detail" className="space-y-8 pb-20">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-zinc-400 hover:text-white transition-colors mb-2">
        <ArrowLeft className="w-4 h-4" /> 返回角色列表
      </button>

      {/* Header Profile */}
      <div className="flex items-end gap-6">
        <div 
          id="btn-edit-avatar"
          className="w-32 h-32 rounded-2xl glass-panel flex items-center justify-center relative overflow-hidden group cursor-pointer" 
          onClick={() => openModal('edit_avatar')}
        >
          <User className="w-12 h-12 text-zinc-600 group-hover:scale-110 transition-transform duration-500" />
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <Edit2 className="w-5 h-5 text-white" />
          </div>
        </div>
        <div className="flex-1 pb-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-4xl font-bold tracking-tight text-white">{name}</h2>
                {isProtagonist && (
                  <span className="bg-white/10 text-white text-xs px-2 py-1 rounded font-medium tracking-wider">
                    PROTAGONIST
                  </span>
                )}
              </div>
              <p className="text-zinc-400 font-mono text-sm">ID: {characterId} | 状态: 活跃</p>
            </div>
            <button id="btn-edit-basic" onClick={() => openModal('edit_basic')} className="glass-button px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 text-zinc-200">
              <Edit2 className="w-4 h-4" /> 编辑基础信息
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Basic Stats */}
        <article className="glass-panel rounded-2xl p-6 space-y-6">
          <div className="flex items-center gap-3 border-b border-white/10 pb-4">
            <Activity className="w-5 h-5 text-zinc-300" />
            <h3 className="text-lg font-medium text-zinc-100">生理指标</h3>
          </div>
          <div className="space-y-4">
            <StatRow label="年龄" value={isProtagonist ? "20 岁" : "17 岁"} />
            <StatRow label="身高" value={isProtagonist ? "180 cm" : "165 cm"} />
            <StatRow label="体重" value={isProtagonist ? "70 kg" : "48 kg"} />
            {!isProtagonist && <StatRow label="三围" value="B88 W58 H89" />}
            <StatRow label="体质" value={isProtagonist ? "规则免疫" : "敏感型"} />
          </div>
          <div className="space-y-4 mt-6 pt-4 border-t border-white/5">
            {!isProtagonist ? (
              <>
                <StatBar label="好感度 AFFECTION" value="42/100" percentage={42} />
                <StatBar label="发情值 LUST" value="75/100" percentage={75} />
                <StatBar label="性癖开发值 FETISH" value="15/100" percentage={15} />
              </>
            ) : (
              <div className="text-center py-2 text-zinc-500 text-sm">
                主角不受常规属性限制。
              </div>
            )}
          </div>
        </article>

        {/* Psychology */}
        <article className="glass-panel rounded-2xl p-6 space-y-6">
          <div className="flex items-center gap-3 border-b border-white/10 pb-4">
            <Brain className="w-5 h-5 text-zinc-300" />
            <h3 className="text-lg font-medium text-zinc-100">心理状态</h3>
          </div>
          <div className="space-y-4">
            <div>
              <span className="text-xs text-zinc-500 uppercase tracking-wider">当前想法</span>
              <p className="text-sm text-zinc-300 mt-1 italic leading-relaxed">
                {isProtagonist ? '"这个世界的规则，由我来制定。"' : '"为什么身体会这么奇怪...明明不想发出那种声音的..."'}
              </p>
            </div>
            <div>
              <span className="text-xs text-zinc-500 uppercase tracking-wider">性格特征</span>
              <div className="flex flex-wrap gap-2 mt-2">
                {isProtagonist ? (
                  <>
                    <Badge text="掌控者" highlight />
                    <Badge text="冷静" />
                    <Badge text="观察者" />
                  </>
                ) : (
                  <>
                    <Badge text="傲娇" />
                    <Badge text="高自尊" />
                    <Badge text="容易害羞" />
                  </>
                )}
              </div>
            </div>
          </div>
        </article>

        {/* Fetishes & Sensitivities */}
        <article className="glass-panel rounded-2xl p-6 space-y-6">
          <div className="flex items-center gap-3 border-b border-white/10 pb-4">
            <Heart className="w-5 h-5 text-zinc-300" />
            <h3 className="text-lg font-medium text-zinc-100">性癖与敏感带</h3>
          </div>
          <div className="space-y-4">
            <div>
              <span className="text-xs text-zinc-500 uppercase tracking-wider">敏感部位</span>
              <div className="flex flex-wrap gap-2 mt-2">
                {isProtagonist ? (
                  <span className="text-sm text-zinc-500">无明显弱点</span>
                ) : (
                  <>
                    <Badge text="耳垂 (Lv.3)" highlight />
                    <Badge text="后颈 (Lv.2)" />
                    <Badge text="大腿内侧 (Lv.4)" highlight />
                  </>
                )}
              </div>
            </div>
            <div>
              <span className="text-xs text-zinc-500 uppercase tracking-wider">隐藏性癖</span>
              <p className="text-sm text-zinc-300 mt-1">
                {isProtagonist ? '喜欢看着他人被规则束缚而逐渐堕落的样子。' : '表面上抗拒，但内心深处对被强制命令有微弱的期待。'}
              </p>
            </div>
          </div>
        </article>
      </div>

      {/* Affected Rules */}
      <article className="glass-panel rounded-2xl p-6">
        <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-zinc-300" />
            <h3 className="text-lg font-medium text-zinc-100">当前受影响规则</h3>
          </div>
          <button id="btn-manage-rules" onClick={() => openModal('manage_rules')} className="text-xs text-zinc-400 hover:text-white transition-colors">
            管理规则影响
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {isProtagonist ? (
            <div className="col-span-full text-center py-4 text-zinc-500 text-sm">
              主角免疫所有负面规则影响。
            </div>
          ) : (
            <>
              <RuleCard 
                type="world" 
                title="猫娘语癖" 
                desc="所有女性说话最后一个字必须用喵结尾。" 
                active 
              />
              <RuleCard 
                type="regional" 
                title="圣华女学院：生理报告" 
                desc="上课时上厕所必须提前报告，报告内容为羞辱自己的话语。" 
                active 
              />
              <RuleCard 
                type="personal" 
                title="赤足禁忌" 
                desc="永远不能穿鞋子，必须时刻感受地面的触感。" 
                active 
              />
            </>
          )}
        </div>
      </article>
    </section>
  );
}

function StatRow({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex justify-between items-center py-1">
      <span className="text-zinc-500 text-sm">{label}</span>
      <span className="text-zinc-100 font-mono text-sm">{value}</span>
    </div>
  );
}

function StatBar({ label, value, percentage }: { label: string, value: string, percentage: number }) {
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-xs">
        <span className="text-zinc-400 uppercase tracking-wider">{label}</span>
        <span className="text-zinc-100 font-mono">{value}</span>
      </div>
      <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="h-full bg-gradient-to-r from-zinc-500 to-zinc-200 rounded-full"
        />
      </div>
    </div>
  );
}

function Badge({ text, highlight = false }: { text: string, highlight?: boolean }) {
  return (
    <span className={`px-2.5 py-1 rounded-md text-xs font-medium border ${
      highlight 
        ? 'bg-zinc-800/80 border-zinc-600 text-zinc-200' 
        : 'bg-white/5 border-white/10 text-zinc-400'
    }`}>
      {text}
    </span>
  );
}

function RuleCard({ type, title, desc, active }: { type: 'world' | 'regional' | 'personal', title: string, desc: string, active: boolean }) {
  const typeColors = {
    world: 'border-l-blue-500',
    regional: 'border-l-emerald-500',
    personal: 'border-l-purple-500'
  };
  
  const typeLabels = {
    world: '世界规则',
    regional: '区域规则',
    personal: '个人规则'
  };

  return (
    <div className={`p-4 rounded-xl glass-panel border-l-2 ${typeColors[type]} hover:bg-white/5 transition-colors group cursor-pointer`}>
      <div className="flex justify-between items-start mb-2">
        <span className="text-[10px] uppercase tracking-wider text-zinc-500">{typeLabels[type]}</span>
        <div className={`w-2 h-2 rounded-full ${active ? 'bg-zinc-300 shadow-[0_0_8px_rgba(255,255,255,0.5)]' : 'bg-zinc-600'}`} />
      </div>
      <h4 className="text-sm font-medium text-zinc-100 mb-1">{title}</h4>
      <p className="text-xs text-zinc-400 line-clamp-2">{desc}</p>
    </div>
  );
}

function WorldRulesPanel({ openModal }: { openModal: (type: string) => void }) {
  return (
    <section id="panel-world-rules" className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-zinc-400 text-sm">影响整个世界所有实体的基础法则。</p>
        <button id="btn-add-world-rule" onClick={() => openModal('add_world_rule')} className="glass-button px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 text-zinc-200">
          <Plus className="w-4 h-4" /> 新增世界规则
        </button>
      </div>

      <div className="space-y-4">
        <RuleListItem 
          title="强制发情期" 
          desc="每个月的第一天，所有成年人都会进入无法抑制的发情状态，持续24小时。"
          status="active"
          openModal={openModal}
        />
        <RuleListItem 
          title="猫娘语癖" 
          desc="所有女性说话最后一个字必须用喵结尾，否则会受到轻微电击惩罚。"
          status="active"
          openModal={openModal}
        />
        <RuleListItem 
          title="开裆裤法案" 
          desc="所有男性在公共场合必须穿着开裆裤。"
          status="inactive"
          openModal={openModal}
        />
      </div>
    </section>
  );
}

function RuleListItem({ title, desc, status, openModal }: { title: string, desc: string, status: string, openModal: (type: string) => void }) {
  return (
    <article className="glass-panel p-5 rounded-2xl flex items-center justify-between group hover:border-white/20 transition-all">
      <div className="flex-1">
        <div className="flex items-center gap-3 mb-1">
          <h4 className="text-base font-medium text-zinc-100">{title}</h4>
          <span className={`px-2 py-0.5 rounded text-[10px] uppercase tracking-wider border ${
            status === 'active' ? 'border-zinc-300/30 text-zinc-200 bg-zinc-300/10' : 'border-zinc-600 text-zinc-500 bg-zinc-800/50'
          }`}>
            {status === 'active' ? '生效中' : '已停用'}
          </span>
        </div>
        <p className="text-sm text-zinc-400">{desc}</p>
      </div>
      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <button onClick={() => openModal('edit_rule')} className="p-2 rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white transition-colors">
          <Edit2 className="w-4 h-4" />
        </button>
        <button onClick={() => openModal('delete_rule')} className="p-2 rounded-lg hover:bg-red-500/20 text-zinc-400 hover:text-red-400 transition-colors">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </article>
  );
}

function RegionalRulesPanel({ openModal }: { openModal: (type: string) => void }) {
  return (
    <section id="panel-regional-rules" className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-zinc-400 text-sm">仅在特定地理区域或建筑内生效的规则。</p>
        <button id="btn-add-region" onClick={() => openModal('add_region')} className="glass-button px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 text-zinc-200">
          <Plus className="w-4 h-4" /> 新增区域
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <RegionCard 
          name="圣华女子高级中学" 
          ruleCount={3} 
          openModal={openModal}
          rules={[
            "上课时上厕所必须提前报告，报告内容为羞辱自己的话语。",
            "禁止穿着内衣，必须真空上阵。",
            "见到教师必须行跪拜礼。"
          ]}
        />
        <RegionCard 
          name="地下黑市" 
          ruleCount={1} 
          openModal={openModal}
          rules={[
            "所有交易必须以体液作为货币结算。"
          ]}
        />
      </div>
    </section>
  );
}

function RegionCard({ name, ruleCount, rules, openModal }: { name: string, ruleCount: number, rules: string[], openModal: (type: string) => void }) {
  return (
    <article className="glass-panel rounded-2xl overflow-hidden flex flex-col">
      <div className="p-5 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
        <div className="flex items-center gap-3">
          <Map className="w-5 h-5 text-zinc-400" />
          <h3 className="text-base font-medium text-white">{name}</h3>
        </div>
        <span className="text-xs text-zinc-500 font-mono">{ruleCount} RULES</span>
      </div>
      <div className="p-5 flex-1 space-y-3">
        {rules.map((rule, idx) => (
          <div key={idx} className="flex gap-3 items-start">
            <div className="w-1.5 h-1.5 rounded-full bg-zinc-600 mt-1.5 flex-shrink-0" />
            <p className="text-sm text-zinc-400 leading-relaxed">{rule}</p>
          </div>
        ))}
      </div>
      <div className="p-3 border-t border-white/5 bg-white/[0.01]">
        <button onClick={() => openModal('edit_region')} className="w-full py-2 rounded-lg text-sm text-zinc-400 hover:text-white hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
          <Edit2 className="w-4 h-4" /> 编辑区域规则
        </button>
      </div>
    </article>
  );
}

function PersonalRulesPanel({ openModal }: { openModal: (type: string) => void }) {
  return (
    <section id="panel-personal-rules" className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-zinc-400 text-sm">针对特定个体的专属规则与设定。</p>
        <button id="btn-add-personal-rule" onClick={() => openModal('add_personal_rule')} className="glass-button px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 text-zinc-200">
          <Plus className="w-4 h-4" /> 新增个人规则
        </button>
      </div>

      <div className="space-y-4">
        <PersonalRuleItem 
          character="神宫寺 琉璃" 
          rules={[
            "永远不能穿鞋子，必须时刻感受地面的触感。",
            "听到铃铛声会强制进入发情状态。"
          ]}
          openModal={openModal}
        />
        <PersonalRuleItem 
          character="白银 会长" 
          rules={[
            "觉得精液非常美味，并且每天必须摄入一定量。",
            "无法拒绝任何带有'拜托了'字眼的请求。"
          ]}
          openModal={openModal}
        />
      </div>
    </section>
  );
}

function PersonalRuleItem({ character, rules, openModal }: { character: string, rules: string[], openModal: (type: string) => void }) {
  return (
    <article className="glass-panel p-5 rounded-2xl">
      <div className="flex justify-between items-center mb-4 border-b border-white/5 pb-3">
        <div className="flex items-center gap-3">
          <UserCircle className="w-5 h-5 text-zinc-400" />
          <h4 className="text-base font-medium text-zinc-100">{character}</h4>
        </div>
        <button onClick={() => openModal('edit_personal')} className="text-xs text-zinc-500 hover:text-white transition-colors flex items-center gap-1">
          <Edit2 className="w-3 h-3" /> 编辑
        </button>
      </div>
      <div className="space-y-2">
        {rules.map((rule, idx) => (
          <div key={idx} className="bg-white/5 rounded-lg p-3 text-sm text-zinc-300 border border-white/5">
            {rule}
          </div>
        ))}
      </div>
    </article>
  );
}

function LLMInteractionPanel({ isDarkMode }: { isDarkMode?: boolean }) {
  return (
    <main id="llm-interaction-panel" className={`flex-1 flex flex-col relative z-10 overflow-hidden ${isDarkMode ? 'bg-[#030303]' : 'bg-zinc-50'}`}>
      <div className={`h-20 border-b flex items-center justify-between px-8 ${isDarkMode ? 'border-white/5' : 'border-black/5'}`}>
        <div className="flex items-center gap-3">
          <MessageSquare className={`w-6 h-6 ${isDarkMode ? 'text-zinc-300' : 'text-zinc-600'}`} />
          <h2 className={`text-lg font-medium tracking-wide ${isDarkMode ? 'text-white' : 'text-zinc-900'}`}>系统日志 / 交互</h2>
        </div>
        <button id="btn-maximize-log" className={`transition-colors ${isDarkMode ? 'text-zinc-500 hover:text-white' : 'text-zinc-400 hover:text-zinc-900'}`}>
          <Maximize2 className="w-5 h-5" />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-8 space-y-8 scroll-smooth">
        <LogEntry 
          type="system" 
          time="10:42:01" 
          isDarkMode={isDarkMode}
          content={<>世界规则 <span className="font-medium">「猫娘语癖」</span> 已生效。所有女性角色的对话输出将自动附加后缀。</>} 
        />
        <LogEntry 
          type="event" 
          time="10:45:22" 
          isDarkMode={isDarkMode}
          content={<>神宫寺 琉璃 进入了 <span className="font-medium">「圣华女子高级中学」</span> 区域。区域规则已覆盖。</>} 
        />
        <LogEntry 
          type="user" 
          time="10:46:00" 
          isDarkMode={isDarkMode}
          content="让琉璃去上厕所。" 
        />
        <LogEntry 
          type="llm" 
          time="10:46:15" 
          isDarkMode={isDarkMode}
          content={<>
            琉璃红着脸，双腿微微夹紧。她想起了这里的规则，咬了咬下唇，屈辱地举起手：“老、老师...我...我是不能憋住尿的废物小穴...请允许我去洗手间...喵...”
            <br/><br/>
            <span className={`text-sm italic ${isDarkMode ? 'text-zinc-500' : 'text-zinc-400'}`}>（心理状态更新：羞耻度上升，顺从度微弱上升）</span>
          </>} 
        />
      </div>

      <div className={`p-6 border-t ${isDarkMode ? 'border-white/5 bg-black/20' : 'border-black/5 bg-white/50'}`}>
        <div className="relative max-w-5xl mx-auto">
          <textarea 
            id="llm-input"
            placeholder="输入指令或描述..." 
            className={`w-full border rounded-2xl py-4 px-6 text-base focus:outline-none focus:ring-1 resize-none h-32 ${
              isDarkMode 
                ? 'bg-white/5 border-white/10 text-white placeholder-zinc-600 focus:border-white/20 focus:ring-white/20' 
                : 'bg-white border-black/10 text-zinc-900 placeholder-zinc-400 focus:border-black/20 focus:ring-black/20 shadow-sm'
            }`}
          />
          <button id="btn-send-llm" className={`absolute bottom-4 right-4 p-3 rounded-xl transition-all ${
            isDarkMode 
              ? 'glass-button text-zinc-300 hover:text-white' 
              : 'bg-zinc-900 text-white hover:bg-zinc-800 shadow-md'
          }`}>
            <Sparkles className="w-5 h-5" />
          </button>
        </div>
      </div>
    </main>
  );
}

function LogEntry({ type, time, content, isDarkMode = true }: { type: string, time: string, content: React.ReactNode, isDarkMode?: boolean }) {
  const isUser = type === 'user';
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-2`}
    >
      <span className="text-xs text-zinc-500 font-mono uppercase tracking-wider">{type} [{time}]</span>
      <div className={`p-5 text-base leading-relaxed max-w-[85%] ${
        isUser 
          ? (isDarkMode ? 'bg-zinc-800 text-zinc-100 rounded-3xl rounded-tr-sm border border-zinc-700 shadow-lg' : 'bg-zinc-900 text-white rounded-3xl rounded-tr-sm shadow-md')
          : (isDarkMode ? 'glass-panel rounded-3xl rounded-tl-sm text-zinc-200' : 'bg-white border border-black/5 rounded-3xl rounded-tl-sm text-zinc-800 shadow-sm')
      }`}>
        {content}
      </div>
    </motion.div>
  );
}

function Modal({ closeModal, type }: { closeModal: () => void, type: string }) {
  return (
    <div id="modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={closeModal}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-2xl glass-panel rounded-2xl shadow-2xl overflow-hidden border border-white/10"
      >
        <div className="flex justify-between items-center p-6 border-b border-white/5 bg-white/[0.02]">
          <h2 className="text-lg font-medium text-white">
            {type.includes('add') ? '新增条目' : '编辑条目'}
          </h2>
          <button id="btn-close-modal" onClick={closeModal} className="text-zinc-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6 min-h-[300px] flex flex-col items-center justify-center text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
            <Settings className="w-8 h-8 text-zinc-600 animate-[spin_4s_linear_infinite]" />
          </div>
          <div>
            <h3 className="text-zinc-200 font-medium mb-1">模态框已就绪</h3>
            <p className="text-sm text-zinc-500 max-w-sm mx-auto">
              此处为 <span className="text-zinc-300 font-mono">{type}</span> 的交互界面。具体表单内容与逻辑将在此处渲染。
            </p>
          </div>
        </div>

        <div className="p-6 border-t border-white/5 bg-black/40 flex justify-end gap-3">
          <button id="btn-cancel-modal" onClick={closeModal} className="px-5 py-2 rounded-lg text-sm font-medium text-zinc-400 hover:text-white hover:bg-white/5 transition-colors">
            取消
          </button>
          <button id="btn-save-modal" onClick={closeModal} className="glass-button px-5 py-2 rounded-lg text-sm font-medium text-white">
            保存更改
          </button>
        </div>
      </motion.div>
    </div>
  );
}
